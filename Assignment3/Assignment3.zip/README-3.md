Student Name: Tina Srivastava 
Student Number:103297230
Student Email: tsrivastava5@myseneca.ca 
Date Created: 09.10.2024

GITHUB URL: https://github.com/tinatintina/web322_assignment/edit/main/README.md VERCEL URL: https://vercel.com/tina-srivastavas-projects/web322-assignment

Technology Stack

Frontend:
Backend: TBD
Database: TBD

Notes

By submitting this as my assignment, I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part of this assignment has been copied manually or electronically from any other source (including web sites) or distributed to other students.
